<?php

abstract class MY_Model extends CI_Model 
{
	public function get_table_name()
	{	
		$class_name = get_class($this);
		
		return str_replace('_model','',$class_name);
	}
	
	public function update($data,$where)
	{
		$this->load->database();
		
		$this->db->reset_query();
		
		foreach($data as $field => $value)
		{
			$this->db->set($field , $value);
		}
		
		$this->db->where($where);
		
		$table = $this->get_table_name();
		
		return $this->db->update($table);
		
    }
				
	public function select_row($where)
	{	
		$this->load->database();
		
		$this->db->reset_query();
		
		$this->db->where($where);
		
		$table = $this->get_table_name();

		$query = $this->db->get($table);
		
		return $query->row();
		
    }
	
	public function select_result($where){
		
		$this->load->database();
		
		$this->db->reset_query();
		
		$this->db->where($where);
		
		$table = $this->get_table_name();
		
		$query = $this->db->get($table);
		
		return $query->result();
		
    }
	
	public function delete($where){
		
		$this->load->database();
		
		$this->db->reset_query();

		$this->db->where($where);
		
		$table = $this->get_table_name();
		
		return $this->db->delete($table);

    }
	
	public function insert($data,&$insert_id)
    {
		$this->load->database();
		
		$this->db->reset_query();
		  
		foreach($data as $field => $value)
		{
			$this->db->set($field , $value);
		}

		$table = $this->get_table_name();
		
        $insert = $this->db->insert($table);
		
		$insert_id = $this->db->insert_id();
		
        return $insert;
    }
}